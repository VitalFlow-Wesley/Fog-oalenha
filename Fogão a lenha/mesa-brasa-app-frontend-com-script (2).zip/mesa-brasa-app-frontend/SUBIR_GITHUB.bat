@echo off
echo ===========================================
echo   Mesa e Brasa - Subir para GitHub
echo ===========================================
echo.

where git >nul 2>nul
if %errorlevel% neq 0 (
  echo ERRO: Git nao encontrado. Instale o Git antes de continuar.
  pause
  exit /b 1
)

git init
git add .
git commit -m "feat: frontend inicial Mesa e Brasa"
git branch -M main
git remote remove origin 2>nul
git remote add origin https://github.com/VitalFlow-Wesley/Fog-oalenha.git
git push -u origin main

echo.
echo ===========================================
echo   Finalizado. Confira no GitHub/Vercel.
echo ===========================================
pause
